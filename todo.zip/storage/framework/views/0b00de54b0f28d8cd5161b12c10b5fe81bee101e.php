<?php $__env->startSection('about'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="about-text">
        <p>This is a simple Todo App.</p>
        <p>To use this app you must register. Then sign in using your username and password.</p>

        <p><b>Developer : </b>Arabi Kabir</p>
        <p><b>Version : </b>1.0</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>