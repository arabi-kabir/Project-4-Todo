<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompletedTodo extends Model
{
    //
}
