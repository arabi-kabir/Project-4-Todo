@extends('Home.master')

@section('about')
    active
@endsection

@section('content')
    <div class="about-text">
        <p>This is a simple Todo App.</p>
        <p>To use this app you must register. Then sign in using your username and password.</p>

        <p><b>Developer : </b>Arabi Kabir</p>
        <p><b>Version : </b>1.0</p>
    </div>
@endsection
