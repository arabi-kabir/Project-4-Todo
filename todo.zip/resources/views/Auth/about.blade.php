@extends('Auth.master')

@section('about')
    active
@endsection

@section('content')
    <section class="container">
        <div class="about-text">
            <p>This is a simple Todo App.</p>
            <p>To use this app you must Sign up. Then sign in using your username and password.</p>

            <p><b>Developer : </b>Arabi Kabir</p>
            <p><b>Version : </b>1.0</p>
        </div>
    </section>
@endsection
